jQuery('#map_canvas').each(function(i){
    jQuery(this).addClass('uniqueName' + i);
});