jQuery(document).ready(function(){
	jQuery('.show-route').collapser({
		target: 'next',
		mode: 'block'
	});	
});// JavaScript Document